# Social Stocks - Analyzing Twitter Sentiment and its Correlation to Stock Price Fluxuations
# Jarod Acanfrio and Cameron Kasper
# ISYE-4350 Systems Engineering and Social Media

rm(list = ls())

#################################################################################################################################
# Imports
library("ROAuth")
library("NLP")
library("syuzhet")
library("tm") 
library("SnowballC") 
library("stringi")
library("topicmodels")
library("ggplot2")
library("rtweet")
library("tidytext")
library("alphavantager")
library("quantmod")
library("car")
library("textclean")
library("wordcloud")
library("ggpubr")

##################################################################################################################################
# Function Definitions

sentiment_scoring_by_period <- function(tweets, prices){
  
  period = 1
  lower_bound = min(tweets$created_at)-1
  upper_bound = prices$timestamp[1]
  
  avg_nrc <- get_nrc_sentiment("")
  nrc_by_period = list()
  tweets_in_period = 0
  
  for(i in 1:length(tweets$text)+1){
    
    if(tweets$created_at[i] > upper_bound || i == length(tweets$text)+1){
     
      avg_nrc = avg_nrc/tweets_in_period
      nrc_by_period[[period]] <- avg_nrc
      
      tweets_in_period = 0
      avg_nrc <- get_nrc_sentiment("")
      period = period + 1
      
      lower_bound = upper_bound
      upper_bound = prices$timestamp[period]
    }
    
    if(i == length(tweets$text)+1){
      break
    }
    
    avg_nrc = avg_nrc + get_nrc_sentiment(tweets$text[i])
    tweets_in_period = tweets_in_period + 1
  }
  
  period_nrc_df = do.call(rbind, nrc_by_period)
  return(period_nrc_df)
}

################################################################################################################################
# Authorization and Token Creation
# Enter our specific keys that grant access to AlphaVantage and Twitter API

# Twitter
consumer_key <- 'PIkNDOuOP1XncLI9Mtp4MEZrO'
consumer_secret <- 'Qk4efz3C703F087zOIQtoNwD0pheSVRNg0C6jKacWRRyI0yBb9'
access_token <- '3165956396-Kt1D2Klnl9eEIbAhNmCTGLsGK5f5RvA8mRlRuTi'
access_secret <- '1saWbKiOulpRfvxNqISBGavlX5Bh8fQDiggoLhiStuXdK'
token <- create_token(app = "socialstocks", consumer_key, consumer_secret, access_token, access_secret)

# AlphaVantage
av_api_key("9IEJA5ADWFMUIX7Z")

################################################################################################################################
# Data Collection
# Pull needed data from API, store as local variable and save as .csv file
# to reuse data later without making pull requests. You have the option to either
# pull new data or read pre-existing file each time you run.

#tweet_set <- search_tweets("I am feeling OR I don't feel OR I feel", type = "mixed", n = 18000, lang = "en", since = "2020-04-06", until = "2020-04-10")
#write_as_csv(tweet_set, "bollen_et_al.csv")
tweet_set <- read.csv("bollen_et_al.csv", header = T) #comment out above lines, uncomment this line to read csv.

#intraday_prices <- av_get(symbol = "DJI", av_fun = "TIME_SERIES_INTRADAY", interval = "30min", outputsize = "full")
#write.csv(intraday_prices, file = "intraday_DJI_30min.csv")
intraday_prices <- read.csv("intraday_DJI_30min.csv", header = T)

###############################################################################################################################
# Data Processing
# Remove non-ascii characters, usernames, punctuation, links, pre/post spacing, convert to lower case
# Trim Twitter and Stock data to cover approximately the same time range, and remove unessecary data fields in each set.
# Convert time data in each set to a common form, POSIXlt.

tweet_set <- tweet_set[c("created_at", "text")]
tweet_set <- tweet_set[order(tweet_set$created_at),] #sort by creation time
tweet_set$created_at <- strptime(tweet_set$created_at, format = "%Y-%m-%d %H:%M:%S")

intraday_prices <- intraday_prices[c("timestamp", "close")]
intraday_prices$timestamp <- strptime(intraday_prices$timestamp, format = "%Y-%m-%d %H:%M:%S")

min_tweet_time <- min(tweet_set$created_at)
max_price_time <- max(intraday_prices$timestamp)
intraday_prices <- intraday_prices[!(intraday_prices$timestamp < min_tweet_time),] #removes all dow values before earliest tweet
tweet_set <- tweet_set[!(tweet_set$created_at > max_price_time), ] #removes all tweets after latest dow value

#filter text of tweets
tweet_set$text <- tolower(tweet_set$text)
tweet_set$text <- gsub("rt", "", tweet_set$text)
tweet_set$text <- gsub("@\\w+", "", tweet_set$text) #replace username
tweet_set$text <- gsub("[[:punct:]]", "", tweet_set$text) #remove punctuation
tweet_set$text <- gsub("http\\w+", "", tweet_set$text) #remove links
tweet_set$text <- gsub("[ |\t]{2,}", "", tweet_set$text) #remove tabs
tweet_set$text <- gsub("^ ", "", tweet_set$text) #remove blank spaces at begining
tweet_set$text <- gsub(" $", "", tweet_set$text) #remove blank spaces at the end
tweet_set$text <- replace_non_ascii(tweet_set$text, replacement = "", remove.nonconverted = T) #remove remaining non-ascii char's

##################################################################################################################################
# Initial Sentiment Analysis
# Look at overall Sentiment Scores for the data set as a whole.
# Check correlation between sentiments themselves to take note of possible collinearity
# Look at correlation of each to intraday_price values.


#generate wordcloud
windows()
wordcloud(tweet_set$text, min.freq = 10, colors=brewer.pal(8, "Dark2"), random.color = TRUE, max.words = 500)

# look at sentiment of entire Tweet set
sentiment_by_tweet <- get_nrc_sentiment(tweet_set$text)
sentiment_by_set <- data.frame(colSums(sentiment_by_tweet[,]))
names(sentiment_by_set) <- "Score"
sentiment_by_set <- cbind("Sentiment" = rownames(sentiment_by_set), sentiment_by_set)
rownames(sentiment_by_set) <- NULL

#generate barplot of sentiments in set
tweet_set_plot <- ggplot(data=sentiment_by_set,aes(x=Sentiment,y=Score))+geom_bar(aes(fill=Sentiment),stat = "identity")+
  theme(legend.position="none")+xlab("Sentiments")+ylab("scores")+
  ggtitle("Sentiments found in Tweets related to General Mood")
windows()
ggarrange(tweet_set_plot, ncol=1, nrow=1)

#heat map of correlation between sentiments, http://www.sthda.com/english/wiki/ggplot2-quick-correlation-matrix-heatmap-r-software-and-data-visualization
#
#
#
#

#####################################################################################################################################
# Aligning Tweets with Intrday intervals and Sentiment Scoring
# See function defined at the top of file.

#call to scoring function which returns data frame of avg sentiment by corresponding price period
sentiment_by_period = sentiment_scoring_by_period(tweet_set, intraday_prices)



######################################################################################################################################
# Simple Linear Regression of Price on Individual Sentiment
# Look to see what sentiments are significant in predicting the price.
# Significant sentiments will be used to develop MLR models.

cor(sentiment_by_period, sentiment_by_period)

anger_model <- lm(intraday_prices$close ~ sentiment_by_period$anger)
summary(anger_model)
anova(anger_model)
cor(intraday_prices$close, sentiment_by_period$anger)

anticipation_model <- lm(intraday_prices$close ~ sentiment_by_period$anticipation)
summary(anticipation_model)
anova(anticipation_model)
cor(intraday_prices$close, sentiment_by_period$anticipation)

disgust_model <- lm(intraday_prices$close ~ sentiment_by_period$disgust)
summary(disgust_model)
anova(disgust_model)
cor(intraday_prices$close, sentiment_by_period$disgust)

fear_model <- lm(intraday_prices$close ~ sentiment_by_period$fear)
summary(fear_model)
anova(fear_model)
cor(intraday_prices$close, sentiment_by_period$fear)

joy_model <- lm(intraday_prices$close ~ sentiment_by_period$joy)
summary(joy_model)
anova(joy_model)
cor(intraday_prices$close, sentiment_by_period$joy)

sadness_model <- lm(intraday_prices$close ~ sentiment_by_period$sadness)
summary(sadness_model)
anova(sadness_model)
cor(intraday_prices$close, sentiment_by_period$sadness)

surprise_model <- lm(intraday_prices$close ~ sentiment_by_period$surprise)
summary(surprise_model)
anova(surprise_model)
cor(intraday_prices$close, sentiment_by_period$surprise)

trust_model <- lm(intraday_prices$close ~ sentiment_by_period$trust)
summary(trust_model)
anova(trust_model)
cor(intraday_prices$close, sentiment_by_period$trust)

negative_model <- lm(intraday_prices$close ~ sentiment_by_period$negative)
summary(negative_model)
anova(negative_model)
cor(intraday_prices$close, sentiment_by_period$negative)

positive_model <- lm(intraday_prices$close ~ sentiment_by_period$positive)
summary(positive_model)
anova(positive_model)
cor(intraday_prices$close, sentiment_by_period$positive)

windows()
par(mfrow = c(5, 2))
plot(sentiment_by_period$anger, intraday_prices$close)
plot(sentiment_by_period$anticipation, intraday_prices$close)
plot(sentiment_by_period$disgust, intraday_prices$close)
plot(sentiment_by_period$fear, intraday_prices$close)
plot(sentiment_by_period$joy, intraday_prices$close)
plot(sentiment_by_period$sadness, intraday_prices$close)
plot(sentiment_by_period$surprise, intraday_prices$close)
plot(sentiment_by_period$trust, intraday_prices$close)
plot(sentiment_by_period$negative, intraday_prices$close)
plot(sentiment_by_period$positive, intraday_prices$close)



###########################################################################################################################
# Multiple Linear Regression
# After identifying significant sentiments, build a model off of them using stepwise selection procedures.
# Check for collinearity amongst covariates by means of variance inflation factors on models of sentiment regressed on other sentiments

multiple_sentiment_model <- lm(intraday_prices$close ~ 1, sentiment_by_period)
step(multiple_sentiment_model, intraday_prices$close ~ sentiment_by_period$positive + sentiment_by_period$surprise + sentiment_by_period$joy + sentiment_by_period$fear + sentiment_by_period$disgust + sentiment_by_period$anticipation + sentiment_by_period$anger )

sentiment_MLR <- lm(intraday_prices$close ~ sentiment_by_period$surprise + sentiment_by_period$anticipation + sentiment_by_period$fear)
summary(sentiment_MLR)

windows()
par(mfrow = c(3,2))
plot(sentiment_MLR)
plot(intraday_prices$close, type = "l"); lines(sentiment_MLR$fitted, col = "red")
plot(intraday_prices$close, sentiment_MLR$fitted)

###########################################################################################################################
# Cross Validation
# Given that we have limited data points, and data from the future should be used to train the past for financial models
# we opt for simple cross validation instead of a k-fold cross validation. We train the model on data from 4/6/2020 to 4/8/2020
# and test it on 4/9/2020 data.

train_tweets <- tweet_set[!(tweet_set$created_at > "2020-04-08 15:30:00"),]
test_tweets <- tweet_set[!(tweet_set$created_at < "2020-04-08 15:30:00"),]

train_prices <- intraday_prices[!(intraday_prices$timestamp > "2020-04-08 15:30:00"),]
test_prices <- intraday_prices[!(intraday_prices$timestamp <= "2020-04-08 15:30:00"),]

sentiment_by_period_training = sentiment_scoring_by_period(train_tweets, train_prices)
train_model <- lm(train_prices$close ~ sentiment_by_period_training$surprise + sentiment_by_period_training$anticipation + sentiment_by_period_training$fear) #+ sentiment_by_period_training$anticipation)
summary(train_model)
anova(train_model)

sentiment_by_period_test = sentiment_scoring_by_period(test_tweets, test_prices)
fitted_test_prices = train_model$coefficients[1] + train_model$coefficients[2]*sentiment_by_period_test$positive
actual_test_diff = test_prices$close - fitted_test_prices
test_SSE = sum(actual_test_diff^2)
test_MSE = test_SSE/(length(train_model$residuals)-length(train_model$coefficients))















